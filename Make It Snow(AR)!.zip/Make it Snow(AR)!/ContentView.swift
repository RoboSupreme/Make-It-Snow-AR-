import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            ARViewContainer()
                .edgesIgnoringSafeArea(.all)
            VStack {
                Spacer()
                Button(action: {
                    // Trigger the explosion at the center of the table
                    ARViewContainer.sharedCoordinator?.triggerExplosion()
                }) {
                    Text("Explode Presents")
                        .font(.headline)
                        .padding()
                        .background(Color.red.opacity(0.7))
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding(.bottom, 20)
            }
        }
    }
}
