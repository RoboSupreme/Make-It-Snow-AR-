import SwiftUI

@main
struct Make_it_Snow_App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
