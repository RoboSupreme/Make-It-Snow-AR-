import SwiftUI
import RealityKit
import ARKit
import Combine

struct ARViewContainer: UIViewRepresentable {
    static var sharedCoordinator: Coordinator?

    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        
        // Enable physics debug visualization
        arView.debugOptions = [.showPhysics]
        
        // Configure AR session
        arView.automaticallyConfigureSession = false
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = [.horizontal]
        configuration.environmentTexturing = .automatic
        
        // Check for people occlusion support
        if ARWorldTrackingConfiguration.supportsFrameSemantics(.personSegmentationWithDepth) {
            configuration.frameSemantics.insert(.personSegmentationWithDepth)
            print("People occlusion enabled")
        } else {
            print("People occlusion not supported on this device")
        }
        
        arView.session.run(configuration)
        arView.session.delegate = context.coordinator

        // Add coaching overlay
        addCoachingOverlay(to: arView, context: context)

        // Set coordinator's reference to arView
        context.coordinator.arView = arView

        // Add scene anchor
        arView.scene.addAnchor(context.coordinator.sceneAnchor)

        return arView
    }

    func updateUIView(_ uiView: ARView, context: Context) {
        // No updates needed
    }

    func makeCoordinator() -> Coordinator {
        let coordinator = Coordinator(self)
        ARViewContainer.sharedCoordinator = coordinator
        return coordinator
    }

    // MARK: - Add Coaching Overlay
    func addCoachingOverlay(to arView: ARView, context: Context) {
        let coachingOverlay = ARCoachingOverlayView()
        coachingOverlay.session = arView.session
        coachingOverlay.delegate = context.coordinator
        coachingOverlay.goal = .horizontalPlane
        coachingOverlay.activatesAutomatically = true
        arView.addSubview(coachingOverlay)

        coachingOverlay.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            coachingOverlay.centerXAnchor.constraint(equalTo: arView.centerXAnchor),
            coachingOverlay.centerYAnchor.constraint(equalTo: arView.centerYAnchor),
            coachingOverlay.widthAnchor.constraint(equalTo: arView.widthAnchor),
            coachingOverlay.heightAnchor.constraint(equalTo: arView.heightAnchor)
        ])
    }

    // MARK: - Coordinator Class
    class Coordinator: NSObject, ARSessionDelegate, ARCoachingOverlayViewDelegate {
        var parent: ARViewContainer
        weak var arView: ARView?
        var sceneAnchor = AnchorEntity()
        var tableEntity: ModelEntity?
        var giftBoxes: [ModelEntity] = []
        var snowflakeTemplate: ModelEntity?
        var tablePlaced = false // Flag to prevent multiple tables

        init(_ parent: ARViewContainer) {
            self.parent = parent
            super.init()
            self.snowflakeTemplate = createSnowflakeEntity()
        }

        // MARK: - ARSessionDelegate Methods
        func session(_ session: ARSession, didAdd anchors: [ARAnchor]) {
            for anchor in anchors {
                if let planeAnchor = anchor as? ARPlaneAnchor, !tablePlaced {
                    tablePlaced = true
                    DispatchQueue.main.async {
                        self.addTable(to: self.sceneAnchor, at: planeAnchor)
                    }
                    break
                }
            }
        }

        // MARK: - Add Table
        func addTable(to sceneAnchor: AnchorEntity, at planeAnchor: ARPlaneAnchor) {
            // Load the table model
            guard let tableModel = try? ModelEntity.loadModel(named: "Simple_Table_untextured") else {
                print("Failed to load table model.")
                return
            }
            tableModel.scale = SIMD3<Float>(repeating: 0.003)
            tableModel.position = SIMD3<Float>(
                planeAnchor.transform.columns.3.x,
                planeAnchor.transform.columns.3.y,
                planeAnchor.transform.columns.3.z
            )

            // Add physics
            tableModel.generateCollisionShapes(recursive: true)
            let tablePhysicsMaterial = PhysicsMaterialResource.generate(
                friction: 1.0,
                restitution: 0.0
            )
            tableModel.physicsBody = PhysicsBodyComponent(
                massProperties: .default,
                material: tablePhysicsMaterial,
                mode: .static
            )

            sceneAnchor.addChild(tableModel)
            self.tableEntity = tableModel

            // Start dropping presents
            self.startDroppingPresents()

            // Start snowfall after table is placed
            self.startSnowfall()
        }

        // MARK: - Start Dropping Presents
        func startDroppingPresents() {
            guard let tableEntity = self.tableEntity else { return }

            // Load the gift box model
            guard let giftBoxModel = try? ModelEntity.loadModel(named: "giftbox") else {
                print("Failed to load gift box model.")
                return
            }

            // Calculate table dimensions
            let tableBounds = tableEntity.visualBounds(relativeTo: nil)
            let tableTopY = tableEntity.position.y + (tableBounds.extents.y / 2)

            // Set up a timer to drop presents periodically
            Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { timer in
                DispatchQueue.main.async {
                    let giftBox = giftBoxModel.clone(recursive: true)
                    giftBox.scale = SIMD3<Float>(repeating: 0.3)

                    // Random position above the table
                    let xOffset = Float.random(in: -0.1...0.1)
                    let zOffset = Float.random(in: -0.1...0.1)
                    let spawnHeight: Float = 3.0 // Meters above the table

                    giftBox.position = SIMD3<Float>(
                        tableEntity.position.x + xOffset,
                        tableTopY + spawnHeight,
                        tableEntity.position.z + zOffset
                    )
                    // don't need this part, the gift box have nice color, but we are keeping it
                    // Simplify material
                    //let simpleMaterial = SimpleMaterial(color: .red, isMetallic: false)
                    //giftBox.model?.materials = [simpleMaterial]

                    // Add physics
                    giftBox.generateCollisionShapes(recursive: true)
                    let giftBoxPhysicsMaterial = PhysicsMaterialResource.generate(
                        friction: 1.0,
                        restitution: 0.0
                    )
                    giftBox.physicsBody = PhysicsBodyComponent(
                        massProperties: .init(mass: 1.0),
                        material: giftBoxPhysicsMaterial,
                        mode: .dynamic
                    )

                    self.sceneAnchor.addChild(giftBox)
                    self.giftBoxes.append(giftBox)
                }
            }
        }

        // MARK: - Trigger Explosion
        func triggerExplosion() {
            guard let tableEntity = self.tableEntity else { return }

            // Position of the explosion (center of the table)
            let explosionPosition = tableEntity.position(relativeTo: nil)

            for giftBox in self.giftBoxes {
                // Calculate direction from explosion center to gift box
                let giftBoxPosition = giftBox.position(relativeTo: nil)
                let direction = normalize(giftBoxPosition - explosionPosition)
                // Apply impulse
                let impulseMagnitude: Float = 0.1 // Adjust the force as needed
                let impulse = direction * impulseMagnitude

                // Apply the impulse at the center of the gift box
                giftBox.applyImpulse(impulse, at: [0, 0, 0], relativeTo: nil)
            }
        }

        // MARK: - Snowfall Methods
        func startSnowfall() {
            guard let arView = self.arView else { return }

            // Set up a timer to spawn snowflakes periodically
            Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { timer in
                // Limit the number of active snowflakes
                let snowflakeCount = self.sceneAnchor.children.filter { $0.name == "Snowflake" }.count
                if snowflakeCount > 1000 {
                    return
                }

                DispatchQueue.main.async {
                    // Create multiple snowflakes in each timer call
                    for _ in 0..<10 { // Adjust the number as needed
                        self.createAndAnimateSnowflake()
                    }
                }
            }
        }

        func createAndAnimateSnowflake() {
            // Create a snowflake entity
            if let snowflake = self.snowflakeTemplate?.clone(recursive: true) {
                // Random position above the scene
                let xRange: ClosedRange<Float> = -1.0...1.0
                let yPosition: Float = 2.0 // 2 meters above the origin
                let zRange: ClosedRange<Float> = -1.0...1.0

                let xPosition = Float.random(in: xRange)
                let zPosition = Float.random(in: zRange)

                snowflake.position = [xPosition, yPosition, zPosition]

                // Optional: Rotate the snowflake randomly
                let randomRotation = simd_quatf(angle: Float.random(in: 0...Float.pi * 2), axis: [0, 1, 0])
                snowflake.orientation = randomRotation

                // Add the snowflake to the scene
                self.sceneAnchor.addChild(snowflake)

                // Animate the snowflake falling
                self.animateSnowflake(snowflake)
            }
        }

        func createSnowflakeEntity() -> ModelEntity? {
            // Load the snowflake model as an Entity
            guard let snowflakeEntity = try? Entity.load(named: "Snowflake") else {
                print("Failed to load snowflake model.")
                return nil
            }

            // Scale all ModelEntities
            let desiredScale = SIMD3<Float>(repeating: 0.01)
            scaleAllModelEntities(in: snowflakeEntity, scale: desiredScale)

            // Set a name for identification
            snowflakeEntity.name = "Snowflake"

            // Wrap the entity in a ModelEntity
            let modelEntity = ModelEntity()
            modelEntity.addChild(snowflakeEntity)

            return modelEntity
        }

        func scaleAllModelEntities(in entity: Entity, scale: SIMD3<Float>) {
            if let modelEntity = entity as? ModelEntity {
                modelEntity.scale = scale
            }
            for child in entity.children {
                scaleAllModelEntities(in: child, scale: scale)
            }
        }

        func animateSnowflake(_ snowflake: ModelEntity) {
            // Define the duration of the fall
            let fallDuration = TimeInterval.random(in: 3.0...7.0)

            // Define the end position (ground level)
            let xOffset = Float.random(in: -0.1...0.1) // Sway effect
            let zOffset = Float.random(in: -0.1...0.1)

            let endPosition = SIMD3<Float>(
                snowflake.position.x + xOffset,
                -0.5, // Slightly below ground to hide the snowflake after falling
                snowflake.position.z + zOffset
            )

            // Use the 'move' method to animate the snowflake
            snowflake.move(to: Transform(translation: endPosition), relativeTo: nil, duration: fallDuration)

            // Remove the snowflake after the animation completes
            DispatchQueue.main.asyncAfter(deadline: .now() + fallDuration) {
                snowflake.removeFromParent()
            }
        }

        // MARK: - ARCoachingOverlayViewDelegate Methods
        func coachingOverlayViewDidDeactivate(_ coachingOverlayView: ARCoachingOverlayView) {
            // Not needed for this example
        }
    }
}
